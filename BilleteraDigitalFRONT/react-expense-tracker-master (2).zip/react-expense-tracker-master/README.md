# React Expense Tracker

React Expense Tracker is a simple expense tracker app built with React and the context API.

# Usage

```
git clone https://github.com/fazt/react-expense-tracker 
cd react-expense-tracker
npm install
npm start
```