export function Header() {
  return (
    <div className="text-4xl font-bold text-center my-5">
      Expense Tracker
    </div>
  )
}